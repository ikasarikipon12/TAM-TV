# TAM TV — Android starter project

Starter Android application for Android 6.0+ (API 23+) with a dark blue TV-oriented interface.

## Included in this starter
- M3U playlist URL loader (HTTP/HTTPS)
- Channel list and playback using AndroidX Media3 / ExoPlayer
- Media3 HLS and DASH modules
- YouTube launch button (opens the YouTube URL using an installed handler/browser)
- ARMv7 (`armeabi-v7a`) and ARM64 (`arm64-v8a`) ABIs
- GitHub Actions workflow to build a debug APK

## Build from GitHub using a phone
1. Create a GitHub repository named `TAM-TV`.
2. Upload the *contents* of this ZIP to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build TAM TV APK**, then choose **Run workflow**. A push to `main` also starts a build.
5. When the run completes, open its run page and download the `TAM-TV-debug-APK` artifact.

The debug APK is for testing. It is not a Play Store release and is not a signed release build.

## Important limitations
- This is an initial starter, not a finished commercial IPTV app.
- VOD catalog browsing, categories, search, favorites, EPG, subtitle/audio selection UI, and advanced remote-control polish are not implemented yet.
- Playlist providers may require headers, tokens, cookies, or DRM. This starter sends a basic `TAMTV/1.0` User-Agent and does not bypass DRM or access controls.
- Actual playback depends on the stream format, codec, device firmware, network, and provider authorization. Test on the target STB.
- The project has not been built or tested on a physical Android 6 device in this environment.

## Package details
- Application ID: `com.tamtv.player`
- Version: `1.0`
- Minimum SDK: 23 (Android 6.0)
- Target SDK: 35
