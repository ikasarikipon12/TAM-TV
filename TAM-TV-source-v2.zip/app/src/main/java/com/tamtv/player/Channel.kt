package com.tamtv.player

data class Channel(val name: String, val url: String)
