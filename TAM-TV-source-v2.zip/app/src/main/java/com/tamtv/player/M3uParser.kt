package com.tamtv.player

object M3uParser {
    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name = "Channel"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) ->
                    name = line.substringAfterLast(",").trim().ifBlank { "Channel" }
                line.isNotEmpty() && !line.startsWith("#") &&
                    (line.startsWith("http://") || line.startsWith("https://")) -> {
                    result += Channel(name, line)
                    name = "Channel"
                }
            }
        }
        return result
    }
}
