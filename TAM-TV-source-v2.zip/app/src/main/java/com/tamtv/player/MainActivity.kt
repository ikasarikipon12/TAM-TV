package com.tamtv.player

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread
import java.net.URL

class MainActivity : AppCompatActivity() {
    private val channels = mutableListOf<Channel>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val urlInput = findViewById<EditText>(R.id.playlistUrl)
        val list = findViewById<ListView>(R.id.channelList)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        list.adapter = adapter
        findViewById<Button>(R.id.loadPlaylist).setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (!url.startsWith("http")) {
                Toast.makeText(this, "Masukkan URL playlist yang benar", Toast.LENGTH_SHORT).show()
            } else loadPlaylist(url)
        }
        list.setOnItemClickListener { _, _, position, _ ->
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", channels[position].url))
        }
        findViewById<Button>(R.id.youtube).setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            startActivity(intent)
        }
    }

    private fun loadPlaylist(url: String) {
        Toast.makeText(this, "Memuat playlist...", Toast.LENGTH_SHORT).show()
        thread {
            try {
                val content = URL(url).openConnection().apply {
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "TAMTV/1.0")
                }.getInputStream().bufferedReader().use { it.readText() }
                val parsed = M3uParser.parse(content)
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    adapter.clear()
                    adapter.addAll(parsed.map { it.name })
                    Toast.makeText(this, "${parsed.size} channel ditemukan", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Gagal memuat: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
